(function(){
    angular.module('app.users', []);
 })();