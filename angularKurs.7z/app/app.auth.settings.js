(function(){
    'use strict';
    (function () {
    'use strict';
    angular
            .module('app')
            .constant('ngAuthSettings', {
                apiServiceBaseUri: "http://94.130.26.112/",
            });
    })();
})();