(function(){
    var mainController = function($scope){
        
    };
    mainController.$inject = ['$scope']
    angular.module("app").controller('mainController', mainController);
})();