(function(){
    var usersFactory = function($http, ngAuthSettings){
        return {
            "getAllUsers": function(){
                return $http.get(ngAuthSettings.apiServiceBaseUri + "account/getAllUsers");
            },
            "accountRegister": function(data){
                return $http.post(ngAuthSettings.apiServiceBaseUri + "account/register", data);
            },
            "getUser": function(id){
                return $http.get(ngAuthSettings.apiServiceBaseUri + "account/getUser/"+id);
            },
            "editUser": function(data){
                return $http.post(ngAuthSettings.apiServiceBaseUri + "account/editUser", data);
            }
        }
    };
    
    usersFactory.$inject = ['$http', 'ngAuthSettings'];
    angular.module("app.users").factory('usersFactory', usersFactory);
})();