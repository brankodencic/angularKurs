(function(){
    var test = function(){
        return {
            required: 'E', //html element mogucnosti: ACME
//            template: `<div>{{$scope.uhvaceniString}}</div>`,
            templateUrl: './app/components/test.directive/test.html',
            controller: function(){
                
            },
//            replace: true, //unisti html tag test iz html-a
//            scope: true, //nasledi scope od parrenta
            scope: {  //koristi izlovani scope
                uhvaceniString: '@', // vrednost tog atributa iz html poziva
                
            },
            link(scope, element, attr, ctrl){
                
            }
            
        }
    };
    angular.module('app').directive('test', test);
})();