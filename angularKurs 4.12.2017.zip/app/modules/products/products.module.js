(function(){
    angular.module('app.products', []);
 })();