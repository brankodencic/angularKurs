(function(){
    var userController = function($scope, authService, $location, usersFactory, $stateParams, $state){
        $scope.userData = {
            Email:null,
            Password:null,
            ConfirmPassword:null,
            Username:null,
            FirstName:null,
            LastName:null,
            Role:null
        }

        console.log('user controller');
            console.log($stateParams);

        if($stateParams.hasOwnProperty('id')){
            usersFactory.getUser($stateParams.id).then(
                function(response){
                    var existingUserData = response.data.data.user;
                    console.log(response);
                    $scope.userData = {
                        id: $stateParams.id,
                        Email: existingUserData.email,
                        Username: existingUserData.userName,
                        LastName: existingUserData.lastName,
                        FirstName: existingUserData.firstName
                    }
//                    console.log('bane');
                },
                function(error){
                    console.log(error);
                }
            );
        }


        $scope.AddCreateNewUser = function(e){
            var apiCall;
            if($stateParams.hasOwnProperty('id')){
                apiCall = usersFactory.editUser($scope.userData);
                $scope.userData.ConfirmPassword = $scope.userData.Password;
            } else {
                apiCall = usersFactory.accountRegister($scope.userData);
            }

            if($scope.userForm.$valid){
                apiCall.then(
                    function(data){
                        console.log(data);
                        $state.go('/users');
                    },
                    function(data){
                        console.log(data);
                    }
                );
            } else {
                console.log("invalid form");
            }

            apiCall();
            e.preventDefault();
        };
        
        $scope.checkIfEdit = function(){
            return $stateParams.hasOwnProperty('id') ? false : true;
        };
    }
    userController.$inject = ['$scope', 'authService', '$location', 'usersFactory', '$stateParams', '$state'];
    angular.module("app.users").controller('userController', userController);
})();