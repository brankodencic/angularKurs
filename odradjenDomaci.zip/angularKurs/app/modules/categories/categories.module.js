(function(){
    angular.module('app.categories', []);
 })();