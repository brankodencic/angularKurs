(function(){
    angular.module('app.dashboard', []);
 })();