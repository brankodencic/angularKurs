(function(){
    angular.module('app.login', []);
 })();