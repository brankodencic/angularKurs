(function(){
    var globalController = function($scope){
        $scope.test = 'Hello world';
    }
    globalController.$inject = ['$scope'];
    angular.module('app').controller('globalController', globalController);
})();