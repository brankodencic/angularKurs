(function(){
    var test = function(){
        return {
            restricted: 'EA', //html element mogucnosti: ACME
//            template: `<div>{{$scope.uhvaceniString}}</div>`,
            templateUrl: './app/components/test.directive/test.html',
            controller: function(){
//                $scope.$on('test-event', function($event, nesto)){
//                    
//                });
            },
//            replace: true, //unisti html tag test iz html-a
//            scope: true, //nasledi scope od parrenta
            scope: {  //koristi izlovani scope
                uhvaceniString: '@', // vrednost tog atributa iz html poziva
//                uhvacenaFunkcija: '&',
//                testAll: '=' //bilo sta, ako se prosledi objekat, bice 2 way binding
                
            },
            link(scope, element, attr, ctrl){
//                $(element).off('click').on('click', function(e){
//                    
//                });
//                angular.element(element).trigger("CLICK");
                
//                $scope.emit('test-event', 'nesto'); //ako je na ovom controlleru
//                $scope.$broadcast('test-event', 'nesto-testings....'); //ako je na nekom childu??
            }
            
        }
    };
    angular.module('app').directive('test', test);
})();