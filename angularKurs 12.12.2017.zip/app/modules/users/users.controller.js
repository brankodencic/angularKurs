(function(){
    var usersController = function($scope, authService, $location, usersFactory){
        usersFactory.getAllUsers().then(
                function(response){
                    $scope.users = response.data.data.users;
                    console.log(response);
                },
                function(error){
                    console.log(error);
                }
            );
    }
    usersController.$inject = ['$scope', 'authService', '$location', 'usersFactory'];
    angular.module("app.users").controller('usersController', usersController);
})();