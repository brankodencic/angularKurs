(function(){
    var categoriesController = function($scope, authService, categoriesFactory, $location, $state){
        $scope.category = {
                "categoryName":null,
                "description":""
        }
        
//        getCategories
        categoriesFactory.getCategories().then(
                function(response){
                    $scope.categories = response.data.data.productCategories;
                    console.log(response);
                },
                function(error){
                    console.log(error);
                }
            );
        
        $scope.addNewCategory = function(e){
            if($scope.categoryForm.$valid){
                categoriesFactory.insertCategory($scope.category).then(
                    function(response){
                        $scope.categories.push(response.data.data.prodCategory);
                        $scope.category.categoryName = null; 
                        // reset form validator
                        $scope.categoryForm.$setPristine();
                        $scope.categoryForm.$setUntouched();
                        console.log(response);
                    },
                    function(error){
                        console.log(error);
                    }
                );
            }
        }
    }
    
    categoriesController.$inject = ['$scope', 'authService', 'categoriesFactory', '$location', '$state'];
    angular.module("app.categories").controller('categoriesController', categoriesController);
})();