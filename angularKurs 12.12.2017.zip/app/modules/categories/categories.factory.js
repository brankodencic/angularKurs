
(function(){
    var categoriesFactory = function($http, ngAuthSettings){
        return {
            getCategories:function(){
                return $http.get(ngAuthSettings.apiServiceBaseUri + "productcategory/getallcategories");
            },
            insertCategory:function(data){
                return $http.post(ngAuthSettings.apiServiceBaseUri + "productcategory/create", data);
            }
        }
    };
    categoriesFactory.$inject = ['$http', 'ngAuthSettings'];
    angular.module('app.categories').factory('categoriesFactory', categoriesFactory);
})();